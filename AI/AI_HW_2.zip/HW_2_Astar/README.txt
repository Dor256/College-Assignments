The code is written in TypeScript - a superset of JavaScript that compiles into JavaScript code.

To run the program, simply open Astar.html in the browser.

To inspect the code, open Astar.ts. Astar.js is the compiled code but is readable as well if preferred.