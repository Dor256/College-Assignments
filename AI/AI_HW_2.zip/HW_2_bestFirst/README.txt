The code is written in TypeScript - a superset of JavaScript that compiles into JavaScript code.

To run the program, simply open bestFirstSearch.html in the browser.

To inspect the code, open bestFirstSearch.ts. bestFirstSearch.js is the compiled code but is readable as well if preferred.