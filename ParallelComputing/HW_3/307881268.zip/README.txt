I've included a Makefile for easy compilation if needed.

In order to compile the project simply run 'make' in the terminal. This will generate main.

In order to run the program the following command should be executed in the terminal:

'make run file=<filename>'

For example, if we want to execute the program with input.txt:

'make run file=input.txt'
