#ifndef HASHSET_H
#define HASHSET_H 1

#include <stdlib.h>

  struct hashset_st {
    size_t nbits;
    size_t mask;

    size_t capacity;
    size_t *items;
    size_t nitems;
    size_t n_deleted_items;
  };

  typedef struct hashset_st *HashSet;

  // Create a hash set
  HashSet createHashSet(void);

  // Destroy a hash set
  void hashSetDestroy(HashSet set);

  size_t hashSetLength(HashSet set);

  // Add an item to the hash set
  int hashSetAdd(HashSet set, void *item);

  // Remove an item from the hash set
  int hashSetRemove(HashSet set, void *item);

  // Check if item is in hash set
  int hashSetHas(HashSet set, void *item);

#endif